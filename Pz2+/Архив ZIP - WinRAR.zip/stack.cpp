#include "stack.h"


Stack* Push(Stack* stack, int num)
{
	Stack* new_el = new Stack;
	new_el->data = num;
	new_el->prev = stack;
	return new_el;
}


int Pop(Stack** stack)
{
	int num;

	if ((*stack))
	{
		Stack* last = *stack;
		num = (*stack)->data;
		*stack = (*stack)->prev;
		delete last;
	}

	else
	{
		num = (*stack)->data;
		delete* stack;
	}
	return num;

}


//int MathAction(Stack** stack, char action)
//{
//
//}