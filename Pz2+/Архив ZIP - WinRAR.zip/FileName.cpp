#include "stack.h"

int main()
{
    setlocale(LC_ALL, "");

    Stack* stack = NULL;

    char symbol;
    int result;

    FILE* resFile;
    FILE* ptr;

    // input
    fopen_s(&ptr, "Test.txt", "r");
    if (ptr != NULL)
    {
        while (fscanf_s(ptr, "%c", &symbol))
        {
            if (symbol >= '0' && symbol <= '9')
            {
                stack = Push(stack, symbol - '0');
            }
            else if (symbol == '+')
            {
                Push(stack, Pop(&stack) + Pop(&stack));
            }
            else if (symbol == '-')
            {
                Push(stack, Pop(&stack) - Pop(&stack));
            }
            else if (symbol == '*')
            {
                Push(stack, Pop(&stack) * Pop(&stack));
            }
        }
    }
    else
    {
        printf_s("Could not open file result.txt\n");
        return 0;
    }

    // output
    fopen_s(&resFile, "result.txt", "w+");

    if (resFile != NULL)
    {
        fprintf(resFile, "%d", Pop(&stack));
    }
    else
    {
        exit(0);
    }

    fclose(resFile);
}
